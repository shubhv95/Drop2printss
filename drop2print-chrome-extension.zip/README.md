# Drop2Print MV3 extension starter

This folder contains a Manifest V3 extension scaffold with a popup/side-panel image grabber and an image context menu.

## Load on desktop Chrome
1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Choose **Load unpacked** and select this `extension` folder.

## Notes
- Chrome does not allow extensions to access browser-internal pages or some protected pages.
- This starter's tab grabber lists image elements and links to each image. It is not a fully tested production extension and does not yet connect every web-studio print workflow into the extension UI.
- The website's full standalone studio is at `../index.html`.
