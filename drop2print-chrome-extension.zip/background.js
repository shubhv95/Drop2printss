chrome.runtime.onInstalled.addListener(()=>{chrome.contextMenus.create({id:"drop2print-image",title:"Open image with Drop2Print",contexts:["image"]});chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});});
chrome.contextMenus.onClicked.addListener((info,tab)=>{if(info.menuItemId==="drop2print-image"&&info.srcUrl){chrome.tabs.create({url:info.srcUrl});}});
